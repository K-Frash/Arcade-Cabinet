#ifndef __COLOURS_H__
#define __COLOURS_H__

enum Colour{White=0, Black};

#endif
