#ifndef __POSN_H__
#define __POSN_H__
#include <utility>

typedef std::pair<int,int> Posn;
typedef std::pair<Posn,Posn> Move;

#endif
